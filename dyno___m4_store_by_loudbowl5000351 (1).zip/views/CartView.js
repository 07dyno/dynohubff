import { getStore, getCart, removeFromCart } from "store";

export class CartView {
  constructor(storeId){ this.storeId = storeId; }
  async render(){
    const s = getStore(this.storeId);
    const cart = getCart(this.storeId);
    const el = document.createElement("div");
    const lines = cart.map(l=>{
      const p = s.products.find(x=>x.id===l.productId);
      return { ...l, name:p?.name||"Produto", image:p?.image||"", price:l.price };
    });
    const total = lines.reduce((sum,l)=>sum + l.qty*l.price, 0);
    el.innerHTML = `
      <header class="header">
        <div class="brand">${s.name}</div>
        <div class="nav">
          <a class="badge" href="#/store/${s.id}">Voltar</a>
          <a class="badge" href="#/checkout/${s.id}">Checkout</a>
        </div>
      </header>
      <div class="container">
        <div class="card">
          <div class="h2">Carrinho</div>
          ${!lines.length ? `<div class="muted">Seu carrinho está vazio.</div>` : `
            <table class="table">
              <thead><tr><th>Produto</th><th>Qtd</th><th>Preço</th><th>Total</th><th></th></tr></thead>
              <tbody>
                ${lines.map(l=>`
                  <tr data-line="${l.id}">
                    <td class="row"><img src="${l.image}" style="width:48px;height:36px;object-fit:cover;border-radius:6px;border:1px solid var(--line)"><div>${l.name}</div></td>
                    <td>${l.qty}</td>
                    <td>R$ ${l.price.toFixed(2)}</td>
                    <td>R$ ${(l.price*l.qty).toFixed(2)}</td>
                    <td><button class="btn-danger" data-del="${l.id}">Remover</button></td>
                  </tr>
                `).join("")}
              </tbody>
            </table>
            <div class="row spread" style="margin-top:10px;">
              <div></div>
              <div class="row"><div class="h2">Total: R$ ${total.toFixed(2)}</div><a href="#/checkout/${s.id}"><button>Ir para checkout</button></a></div>
            </div>
          `}
        </div>
      </div>
    `;
    el.addEventListener("click",(e)=>{
      const btn = e.target.closest("[data-del]");
      if (btn){ removeFromCart(this.storeId, btn.dataset.del); location.reload(); }
    });
    return el;
  }
}

