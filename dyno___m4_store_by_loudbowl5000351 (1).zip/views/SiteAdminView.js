export class SiteAdminView {
  constructor(){ this.authed = this.isAuthed(); }
  isAuthed(){ try{ return JSON.parse(sessionStorage.getItem("site.admin.auth"))===true; }catch{ return false; } }
  setAuthed(v){ sessionStorage.setItem("site.admin.auth", JSON.stringify(!!v)); }
  async render(){
    const el = document.createElement("div");
    if (!this.authed) {
      el.innerHTML = `
        <header class="header"><div class="brand">Admin do Site</div><div class="nav"><a class="badge" href="#/">Início</a></div></header>
        <div class="container">
          <div class="card" style="max-width:420px;margin:40px auto;">
            <div class="h2">Login Administrativo (Geral)</div>
            <label>Senha</label>
            <input id="pwd" type="password" placeholder="Senha">
            <div class="row" style="margin-top:10px;">
              <button id="login">Entrar</button><span id="err" class="muted"></span>
            </div>
          </div>
        </div>`;
      el.addEventListener("click",(e)=>{
        if(e.target.id==="login"){
          const p = el.querySelector("#pwd").value.trim();
          if (p==="m4321" || p==="07dyn0sv2"){ this.setAuthed(true); location.reload(); }
          else el.querySelector("#err").textContent = "Senha incorreta.";
        }
      });
      return el;
    }
    const { getSettings, setSettings, listStores } = await import("store");
    const s = getSettings();
    el.innerHTML = `
      <header class="header">
        <div class="brand">Admin do Site</div>
        <div class="nav"><a class="badge" href="#/">Início</a><a class="badge" href="#" id="logout">Sair</a></div>
      </header>
      <div class="container">
        <div class="tabbar"><button data-tab="general" class="active">Geral</button><button data-tab="stores">Lojas</button></div>
        <div class="sep"></div>
        <div class="card" data-panel="general">
          <div class="h2">Configurações Globais</div>
          <div class="input-row">
            <div><label>URL da música (MP3)</label><input id="musicUrl" value="${s.musicUrl||''}" placeholder="https://...mp3"></div>
            <div><label>Link do Suporte (Discord)</label><input id="supportLink" value="${s.supportLink||''}" placeholder="https://discord.gg/..."></div>
            <div style="grid-column:1/-1;"><label>Fundos da Página Inicial (1 URL por linha)</label><textarea id="homeBgs" rows="4">${(s.homeBackgrounds||[]).join("\n")}</textarea></div>
          </div>
          <div class="row" style="margin-top:10px;"><button id="save">Salvar</button></div>
          <div class="note" style="margin-top:8px;">A música toca em loop e há um botão flutuante de Suporte quando o link é definido.</div>
        </div>
        <div class="card" data-panel="stores" style="display:none;">
          <div class="h2">Fundos por Loja</div>
          ${listStores().map(st=>`
            <div class="card" style="margin-top:10px;">
              <div class="h2" style="margin:0 0 6px;">${st.name}</div>
              <label>Imagens de Fundo (1 URL por linha)</label>
              <textarea rows="4" data-store-bgs="${st.id}">${(s.storeBackgrounds?.[st.id]||[]).join("\n")}</textarea>
            </div>
          `).join("")}
          <div class="row" style="margin-top:10px;"><button id="saveStores">Salvar Fundos</button></div>
          <div class="note" style="margin-top:8px;">As imagens serão usadas como plano de fundo rotativo na loja correspondente.</div>
        </div>
      </div>`;
    el.addEventListener("click",(e)=>{
      const tabBtn = e.target.closest("[data-tab]"); if (tabBtn){ const id=tabBtn.dataset.tab; el.querySelectorAll(".tabbar button").forEach(b=>b.classList.toggle("active", b===tabBtn)); el.querySelectorAll("[data-panel]").forEach(p=>p.style.display = p.dataset.panel===id?"":"none"); }
      if (e.target.id==="save"){
        const musicUrl = el.querySelector("#musicUrl").value.trim();
        const supportLink = el.querySelector("#supportLink").value.trim();
        const homeBackgrounds = el.querySelector("#homeBgs").value.split("\n").map(v=>v.trim()).filter(Boolean);
        setSettings({ musicUrl, supportLink, homeBackgrounds }); alert("Configurações salvas.");
      }
      if (e.target.id==="saveStores"){
        const storeBackgrounds = {};
        el.querySelectorAll("[data-store-bgs]").forEach(t=>{ storeBackgrounds[t.dataset.storeBgs] = t.value.split("\n").map(v=>v.trim()).filter(Boolean); });
        setSettings({ storeBackgrounds }); alert("Fundos das lojas salvos.");
      }
      if (e.target.id==="logout"){ e.preventDefault(); this.setAuthed(false); location.reload(); }
    });
    return el;
  }
}