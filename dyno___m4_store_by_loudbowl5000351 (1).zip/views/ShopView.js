import { getStore, addToCart } from "store";

export class ShopView {
  constructor(storeId){ this.storeId = storeId; }
  async render() {
    const s = getStore(this.storeId);
    const el = document.createElement("div");
    const cats = [{ id:"", name:"Tudo"}, ...s.categories];
    el.innerHTML = `
      <header class="header">
        <div class="brand">${s.name}</div>
        <div class="nav">
          <a class="badge" href="#/">Trocar loja</a>
          <a class="badge" href="#/orders/${s.id}">Pedidos</a>
          <a class="badge" href="#/tickets/${s.id}">Tickets</a>
          <a class="badge" href="#/cart/${s.id}">Carrinho</a>
          <a class="badge" href="#/admin/${s.id}">Admin</a>
        </div>
      </header>
      <div class="container">
        <div class="row wrap toolbar">
          ${cats.map(c=>`<button class="btn-ghost" data-cat="${c.id}">${c.name}</button>`).join("")}
        </div>
        <div class="sep"></div>
        <div class="grid cols-4" id="prodGrid">
          ${s.products.map(p=>`
            <div class="card product-card" data-cat="${p.categoryId||''}">
              <img alt="${p.name}" src="${p.image||''}">
              <div class="h2">${p.name}</div>
              <div class="muted">${p.description||""}</div>
              <div class="row spread" style="margin-top:.4rem;">
                <div class="price">R$ ${p.price.toFixed(2)}</div>
                <button data-add="${p.id}" ${p.stock<=0?"disabled":""}>${p.stock>0?"Adicionar":"Esgotado"}</button>
              </div>
            </div>
          `).join("")}
        </div>
      </div>
      <div class="toast" id="toast">Adicionado ao carrinho</div>
    `;
    el.addEventListener("click",(e)=>{
      const btn = e.target.closest("button[data-add]");
      if (btn) {
        addToCart(this.storeId, btn.dataset.add, 1);
        const t = el.querySelector("#toast"); t.classList.add("show"); setTimeout(()=>t.classList.remove("show"),1200);
      }
      const filterBtn = e.target.closest("button[data-cat]");
      if (filterBtn){
        const cat = filterBtn.dataset.cat;
        el.querySelectorAll(".toolbar button").forEach(b=>b.classList.toggle("active", b===filterBtn));
        el.querySelectorAll("#prodGrid > .card").forEach(c=>{
          c.style.display = !cat || c.dataset.cat===cat ? "" : "none";
        });
      }
    });
    return el;
  }
}