import { getStore, getCart, createOrder } from "store";

export class CheckoutView {
  constructor(storeId){ this.storeId = storeId; }
  async render(){
    const s = getStore(this.storeId);
    const cart = getCart(this.storeId);
    const total = cart.reduce((sum,l)=>sum + l.qty*l.price, 0);
    const el = document.createElement("div");
    el.innerHTML = `
      <header class="header">
        <div class="brand">${s.name}</div>
        <div class="nav">
          <a class="badge" href="#/cart/${s.id}">Carrinho</a>
          <a class="badge" href="#/store/${s.id}">Loja</a>
        </div>
      </header>
      <div class="container">
        <div class="grid cols-2">
          <div class="card">
            <div class="h2">Pagamento via Pix</div>
            <div class="row wrap">
              <div>
                <div class="muted">Chave Pix</div>
                <div class="h2">${s.pix.key || "Não configurado"}</div>
              </div>
              <div style="margin-left:auto">
                ${s.pix.qrUrl ? `<img src="${s.pix.qrUrl}" alt="QR Pix" style="width:180px;height:180px;object-fit:contain;border:1px solid var(--line);border-radius:10px;">` : `<div class="muted">QR não configurado</div>`}
              </div>
            </div>
            <div class="note">Após efetuar o pagamento, clique em Finalizar pedido. O pedido ficará pendente até confirmação do vendedor.</div>
          </div>
          <div class="card">
            <div class="h2">Resumo</div>
            ${!cart.length ? `<div class="muted">Carrinho vazio.</div>` : `
              <ul style="list-style:none;padding:0;margin:0;">
                ${cart.map(l=>`<li class="row spread"><span>${l.qty}× ${s.products.find(p=>p.id===l.productId)?.name||'Produto'}</span><b>R$ ${(l.qty*l.price).toFixed(2)}</b></li>`).join("")}
              </ul>
              <div class="sep"></div>
              <div class="row spread"><div>Total</div><div class="h2">R$ ${total.toFixed(2)}</div></div>
              <div class="sep"></div>
              <div class="input-row">
                <div><label>Seu nome</label><input id="custName" placeholder="Seu nome"></div>
              </div>
              <button id="finish">Finalizar pedido</button>
            `}
          </div>
        </div>
      </div>
    `;
    el.addEventListener("click", async (e)=>{
      if (e.target.id==="finish"){
        try {
          const name = el.querySelector("#custName").value.trim() || "Convidado";
          const order = createOrder(this.storeId, { name });
          alert(`Pedido criado! ID: ${order.id}\nStatus: pendente.\nAguarde confirmação do vendedor.`);
          location.hash = `#/orders/${this.storeId}`;
        } catch(err){ alert(err.message); }
      }
    });
    return el;
  }
}

