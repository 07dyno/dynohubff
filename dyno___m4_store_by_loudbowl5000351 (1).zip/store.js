const KEY = "dualshop.v1";
const uid = () => Math.random().toString(36).slice(2, 9);

const emptyStore = (id, name) => ({
  id, name,
  pix: { key: "", qrUrl: "" },
  categories: [],
  products: [],
  orders: [],
  tickets: []
});

const seed = {
  dyno: {
    id: "dyno",
    name: "Dyno Store",
    pix: { key: "dyno@pix.com", qrUrl: "https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=PIX_DYNO_EXAMPLE" },
    categories: [{ id:"c1", name:"Gift Cards" }, { id:"c2", name:"Robux" }],
    products: [
      { id:"p1", name:"Robux Pack 800", description:"800 Robux", price:39.90, stock:20, image:"https://images.unsplash.com/photo-1556745753-b2904692b3cd?q=80&w=600&auto=format&fit=crop" , categoryId:"c2" },
      { id:"p2", name:"Robux Pack 1700", description:"1700 Robux", price:79.90, stock:10, image:"https://images.unsplash.com/photo-1545235617-9465d2a55698?q=80&w=600&auto=format&fit=crop", categoryId:"c2" }
    ],
    orders: [],
    tickets: []
  },
  m4: {
    id: "m4",
    name: "M4 Store",
    pix: { key: "m4@pix.com", qrUrl: "https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=PIX_M4_EXAMPLE" },
    categories: [{ id:"c3", name:"Upgrades" }, { id:"c4", name:"Gamepasses" }],
    products: [
      { id:"p3", name:"VIP Access", description:"Acesso VIP no jogo", price:29.90, stock:15, image:"https://images.unsplash.com/photo-1511512578047-dfb367046420?q=80&w=600&auto=format&fit=crop", categoryId:"c3" }
    ],
    orders: [],
    tickets: []
  }
};

function load() {
  const raw = localStorage.getItem(KEY);
  if (!raw) return null;
  try { return JSON.parse(raw); } catch { return null; }
}
function save(db) { localStorage.setItem(KEY, JSON.stringify(db)); }

// auth session
const AUTH_KEY = "dualshop.auth.v1";
function getAuth() { try { return JSON.parse(sessionStorage.getItem(AUTH_KEY)) || {}; } catch { return {}; } }
function saveAuth(a) { sessionStorage.setItem(AUTH_KEY, JSON.stringify(a)); }

export function ensureSeed() {
  let db = load();
  if (!db) {
    db = { stores: { dyno: seed.dyno, m4: seed.m4 }, carts: {}, settings: { musicUrl:"", supportLink:"", homeBackgrounds: [
      "https://images.unsplash.com/photo-1548498900-3dfbdfff16d1?q=80&w=1600&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1549880338-65ddcdfd017b?q=80&w=1600&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1508057198894-247b23fe5ade?q=80&w=1600&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1519681393784-d120267933ba?q=80&w=1600&auto=format&fit=crop"
    ], storeBackgrounds: { dyno: [], m4: [] } } };
    save(db);
  }
}

function getDB() { return load() || { stores:{}, carts:{}, settings:{ musicUrl:"", supportLink:"", homeBackgrounds: [], storeBackgrounds: {} } }; }

export function getSettings(){ return getDB().settings || { musicUrl:"", supportLink:"", homeBackgrounds: [], storeBackgrounds: {} }; }
export function setSettings(patch){ const db=getDB(); db.settings = { ...(db.settings||{}), ...patch }; save(db); }

export function listStores() {
  const db = getDB();
  const entries = Array.isArray(db.stores) ? db.stores : Object.values(db.stores);
  const map = new Map();
  entries.forEach(s => { if (s && s.id && !map.has(s.id)) map.set(s.id, s); });
  return Array.from(map.values());
}

export function getStore(storeId) {
  return getDB().stores[storeId] || emptyStore(storeId, storeId);
}

export function setPix(storeId, { key, qrUrl }) {
  const db = getDB();
  db.stores[storeId].pix = { key, qrUrl };
  save(db);
}

export function addCategory(storeId, name) {
  const db = getDB();
  const cat = { id: uid(), name };
  db.stores[storeId].categories.push(cat);
  save(db); return cat;
}

export function removeCategory(storeId, id) {
  const db = getDB();
  db.stores[storeId].categories = db.stores[storeId].categories.filter(c=>c.id!==id);
  db.stores[storeId].products = db.stores[storeId].products.map(p=>p.categoryId===id? {...p, categoryId:null}:p);
  save(db);
}

export function addProduct(storeId, data) {
  const db = getDB();
  const prod = { id: uid(), ...data };
  db.stores[storeId].products.push(prod);
  save(db); return prod;
}

export function updateProduct(storeId, id, patch) {
  const db = getDB();
  db.stores[storeId].products = db.stores[storeId].products.map(p=>p.id===id? {...p, ...patch}:p);
  save(db);
}

export function removeProduct(storeId, id) {
  const db = getDB();
  db.stores[storeId].products = db.stores[storeId].products.filter(p=>p.id!==id);
  save(db);
}

export function getCart(storeId) {
  const db = getDB(); db.carts[storeId] ||= [];
  save(db); return db.carts[storeId];
}

export function addToCart(storeId, productId, qty=1) {
  const db = getDB();
  db.carts[storeId] ||= [];
  const p = db.stores[storeId].products.find(x=>x.id===productId);
  const line = db.carts[storeId].find(l=>l.productId===productId);
  if (line) line.qty += qty; else db.carts[storeId].push({ id: uid(), productId, qty, price: p.price });
  save(db);
}

export function removeFromCart(storeId, lineId) {
  const db = getDB();
  db.carts[storeId] = (db.carts[storeId]||[]).filter(l=>l.id!==lineId);
  save(db);
}

export function clearCart(storeId) {
  const db = getDB();
  db.carts[storeId] = [];
  save(db);
}

export function createOrder(storeId, customer={ name:"Convidado"}) {
  const db = getDB();
  const cart = db.carts[storeId]||[];
  if (!cart.length) throw new Error("Carrinho vazio");
  const store = db.stores[storeId];
  const items = cart.map(l=>{
    const p = store.products.find(x=>x.id===l.productId);
    return { productId:l.productId, name:p.name, qty:l.qty, unit:l.price, total: +(l.qty*l.price).toFixed(2) };
  });
  const total = +items.reduce((s,i)=>s+i.total,0).toFixed(2);
  const order = { id: uid(), createdAt: Date.now(), status:"pending", items, total, customer, pix: store.pix };
  store.orders.push(order);
  db.carts[storeId] = [];
  save(db);
  return order;
}

export function listOrders(storeId) {
  const db = getDB();
  return [...db.stores[storeId].orders].sort((a,b)=>b.createdAt-a.createdAt);
}

export function setOrderStatus(storeId, orderId, status) {
  const db = getDB();
  const orders = db.stores[storeId].orders;
  const idx = orders.findIndex(o=>o.id===orderId);
  if (idx>-1) orders[idx].status = status;
  save(db);
}

export function ensureTicket(storeId, orderId) {
  const db = getDB();
  const key = `${storeId}:${orderId}`;
  const t = db.stores[storeId].tickets.find(t=>t.orderId===orderId);
  if (t) return t;
  const ticket = { id: uid(), orderId, messages: [{ id:uid(), from:"system", text:"Ticket criado.", at:Date.now() }] };
  db.stores[storeId].tickets.push(ticket);
  save(db);
  return ticket;
}

export function listTickets(storeId) {
  const db = getDB();
  return [...db.stores[storeId].tickets].sort((a,b)=>b.messages.at(-1).at - a.messages.at(-1).at);
}

export function postMessage(storeId, ticketId, { from, text }) {
  const db = getDB();
  const t = db.stores[storeId].tickets.find(t=>t.id===ticketId);
  if (!t) return;
  t.messages.push({ id:uid(), from, text, at:Date.now() });
  save(db);
}

export function ticketByOrder(storeId, orderId) {
  const db = getDB();
  return db.stores[storeId].tickets.find(t=>t.orderId===orderId);
}

export function verifyAdmin(storeId, password) {
  const ok = (storeId === "m4" && password === "m4321") || (storeId === "dyno" && password === "07dyn0sv2");
  if (ok) { const a = getAuth(); a[storeId] = true; saveAuth(a); }
  return ok;
}

export function isAuthed(storeId) { return !!getAuth()[storeId]; }
export function signOut(storeId) { const a = getAuth(); delete a[storeId]; saveAuth(a); }