export class Router {
  constructor(root) { this.root = root; this.routes = {}; window.addEventListener("hashchange", () => this.render()); }
  start() { if (!location.hash) location.hash = "#/"; this.render(); }
  async render() {
    const hash = location.hash.slice(1) || "/";
    const [_, route, a, b] = hash.split("/");
    const params = { storeId: a, id: b };
    let view;
    switch (route || "") {
      case "": {
        const { HomeView } = await import("views/home"); view = new HomeView(); break;
      }
      case "store": {
        const { ShopView } = await import("views/shop"); view = new ShopView(params.storeId); break;
      }
      case "admin": {
        const { AdminView } = await import("views/admin"); view = new AdminView(params.storeId); break;
      }
      case "cart": {
        const { CartView } = await import("views/cart"); view = new CartView(params.storeId); break;
      }
      case "checkout": {
        const { CheckoutView } = await import("views/checkout"); view = new CheckoutView(params.storeId); break;
      }
      case "orders": {
        const { OrdersView } = await import("views/orders"); view = new OrdersView(params.storeId); break;
      }
      case "tickets": {
        const { TicketsView } = await import("views/tickets"); view = new TicketsView(params.storeId); break;
      }
      case "site-admin": {
        const { SiteAdminView } = await import("views/siteAdmin"); view = new SiteAdminView(); break;
      }
      default: {
        const { HomeView } = await import("views/home"); view = new HomeView(); break;
      }
    }
    this.root.innerHTML = "";
    this.root.appendChild(await view.render());
    if (view.afterRender) view.afterRender();
  }
}