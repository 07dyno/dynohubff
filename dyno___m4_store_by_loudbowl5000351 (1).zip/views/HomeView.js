import { listStores } from "store";

export class HomeView {
  async render() {
    const el = document.createElement("div");
    const stores = listStores();
    const { getSettings } = await import("store"); const settings = getSettings();
    el.innerHTML = `
      <header class="header">
        <div class="brand">Dyno + M4</div>
        <div class="nav">
          <a class="badge" href="#/">Início</a>
          ${settings.supportLink ? `<a class="badge" href="${settings.supportLink}" target="_blank" rel="noopener">Suporte</a>` : ``}
          <a class="badge" href="#/site-admin">Admin do Site</a>
        </div>
      </header>
      <div class="container">
        <h1 class="h1">Escolha uma loja</h1>
        <div class="grid cols-3" style="margin-bottom:14px;">
          ${(settings.homeBackgrounds?.slice(0,3).length?settings.homeBackgrounds:[]).slice(0,3).map(u=>`<div class="card"><img src="${u}" alt="Fundo destaque" style="border-radius:8px; aspect-ratio:16/9; object-fit:cover;"></div>`).join("")}
        </div>
        <div class="grid cols-2">
          ${stores.map(s=>`
            <div class="card">
              <div class="row spread">
                <div>
                  <div class="h2">${s.name}</div>
                  <div class="muted">Catálogo, carrinho, checkout e tickets</div>
                </div>
                <div class="row">
                  <a href="#/store/${s.id}" class="btn-ghost" style="display:inline-flex;align-items:center;padding:.6rem .9rem;">Entrar</a>
                  <a href="#/admin/${s.id}" class="btn-ghost" style="display:inline-flex;align-items:center;padding:.6rem .9rem;">Admin</a>
                </div>
              </div>
              <div class="sep"></div>
              <div class="grid cols-3">
                ${s.categories.slice(0,3).map(c=>`<span class="badge">${c.name}</span>`).join("")}
              </div>
            </div>
          `).join("")}
        </div>
      </div>
    `;
    return el;
  }
}