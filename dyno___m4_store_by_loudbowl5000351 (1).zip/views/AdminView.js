import { getStore, addProduct, updateProduct, removeProduct, addCategory, removeCategory, setPix, listOrders, setOrderStatus, ensureTicket, verifyAdmin, isAuthed, signOut } from "store";

export class AdminView {
  constructor(storeId){ this.storeId = storeId; this.tab = "products"; }
  tabs(){ return [
    { id:"products", name:"Produtos" },
    { id:"categories", name:"Categorias" },
    { id:"pix", name:"Pix" },
    { id:"orders", name:"Pedidos" },
    { id:"tickets", name:"Tickets" }
  ]; }
  async render(){
    const s = getStore(this.storeId);
    const el = document.createElement("div");
    if (!isAuthed(this.storeId)) {
      el.innerHTML = `
        <header class="header">
          <div class="brand">${s.name} • Admin</div>
          <div class="nav"><a class="badge" href="#/">Início</a></div>
        </header>
        <div class="container">
          <div class="card" style="max-width:420px;margin:40px auto;">
            <div class="h2">Login Administrativo</div>
            <div class="muted">Insira a senha para acessar o painel da ${s.name}.</div>
            <div class="sep"></div>
            <label>Senha</label>
            <input id="adminPass" type="password" placeholder="Senha da loja">
            <div class="row" style="margin-top:10px;">
              <button id="adminLoginBtn">Entrar</button>
              <span id="loginErr" class="muted" style="margin-left:8px;"></span>
            </div>
          </div>
        </div>
      `;
      el.addEventListener("click", (e)=>{
        if (e.target.id === "adminLoginBtn") {
          const pass = el.querySelector("#adminPass").value;
          if (verifyAdmin(this.storeId, pass)) location.reload();
          else el.querySelector("#loginErr").textContent = "Senha incorreta.";
        }
      });
      return el;
    }
    el.innerHTML = `
      <header class="header">
        <div class="brand">${s.name} • Admin</div>
        <div class="nav">
          <a class="badge" href="#/store/${s.id}">Ver loja</a>
          <a class="badge" href="#/">Início</a>
          <a class="badge" href="#" id="logoutBtn">Sair</a>
        </div>
      </header>
      <div class="container">
        <div class="tabbar">
          ${this.tabs().map(t=>`<button data-tab="${t.id}" class="${this.tab===t.id?'active':''}">${t.name}</button>`).join("")}
        </div>
        <div class="sep"></div>
        <div id="panel"></div>
      </div>
    `;
    this.panel = el.querySelector("#panel");
    el.addEventListener("click",(e)=>{
      const tabBtn = e.target.closest("button[data-tab]");
      if (tabBtn){ this.tab = tabBtn.dataset.tab; el.querySelectorAll(".tabbar button").forEach(b=>b.classList.toggle("active", b===tabBtn)); this.renderTab(); }
      if (e.target && e.target.id === "logoutBtn") { e.preventDefault(); signOut(this.storeId); location.reload(); }
    });
    this.el = el;
    this.renderTab();
    return el;
  }
  renderTab(){
    const s = getStore(this.storeId);
    if (this.tab==="products") this.panel.innerHTML = this.productsTab(s);
    if (this.tab==="categories") this.panel.innerHTML = this.categoriesTab(s);
    if (this.tab==="pix") this.panel.innerHTML = this.pixTab(s);
    if (this.tab==="orders") this.panel.innerHTML = this.ordersTab(s);
    if (this.tab==="tickets") this.panel.innerHTML = this.ticketsTab(s);
    this.bindEvents();
  }
  productsTab(s){
    return `
      <div class="card">
        <div class="h2">Adicionar produto</div>
        <div class="input-row">
          <div><label>Nome</label><input id="pName"></div>
          <div><label>Preço (R$)</label><input id="pPrice" type="number" step="0.01"></div>
          <div><label>Categoria</label>
            <select id="pCat">
              <option value="">Sem categoria</option>
              ${s.categories.map(c=>`<option value="${c.id}">${c.name}</option>`).join("")}
            </select>
          </div>
          <div><label>Estoque</label><input id="pStock" type="number" min="0"></div>
          <div style="grid-column:1/-1;"><label>Imagem (URL)</label><input id="pImg" placeholder="https://..."></div>
          <div style="grid-column:1/-1;"><label>Descrição</label><textarea id="pDesc" rows="3"></textarea></div>
        </div>
        <div class="row" style="margin-top:10px;"><button id="addProd">Adicionar</button></div>
      </div>
      <div class="sep"></div>
      <div class="card">
        <div class="h2">Produtos</div>
        <table class="table">
          <thead><tr><th>Produto</th><th>Preço</th><th>Estoque</th><th>Categoria</th><th></th></tr></thead>
          <tbody>
            ${s.products.map(p=>`
              <tr data-id="${p.id}">
                <td>${p.name}</td>
                <td>R$ ${p.price.toFixed(2)}</td>
                <td>${p.stock}</td>
                <td>${s.categories.find(c=>c.id===p.categoryId)?.name||"-"}</td>
                <td class="row">
                  <button class="btn-ghost" data-edit="${p.id}">Editar</button>
                  <button class="btn-danger" data-del="${p.id}">Remover</button>
                </td>
              </tr>
            `).join("")}
          </tbody>
        </table>
      </div>
    `;
  }
  categoriesTab(s){
    return `
      <div class="card">
        <div class="h2">Categorias</div>
        <div class="row">
          <input id="cName" placeholder="Nome da categoria">
          <button id="addCat">Adicionar</button>
        </div>
        <div class="sep"></div>
        <div class="grid cols-3">
          ${s.categories.map(c=>`
            <div class="card row spread" data-cid="${c.id}">
              <div>${c.name}</div>
              <button class="btn-danger" data-cdel="${c.id}">Remover</button>
            </div>
          `).join("")}
        </div>
      </div>
    `;
  }
  pixTab(s){
    return `
      <div class="card">
        <div class="h2">Configurar Pix</div>
        <div class="input-row">
          <div><label>Chave Pix</label><input id="pixKey" value="${s.pix.key||''}"></div>
          <div><label>URL do QR Code</label><input id="qrUrl" value="${s.pix.qrUrl||''}"></div>
        </div>
        <div class="row" style="margin-top:10px;"><button id="savePix">Salvar</button></div>
        <div class="sep"></div>
        <div class="row wrap">
          <div class="card"><div class="muted">Prévia do QR</div><img src="${s.pix.qrUrl||''}" alt="QR Code" style="width:180px;height:180px;object-fit:contain"></div>
          <div class="card"><div class="muted">Chave</div><div class="h2">${s.pix.key||'-'}</div></div>
        </div>
      </div>
    `;
  }
  ordersTab(s){
    const orders = listOrders(this.storeId);
    return `
      <div class="card">
        <div class="h2">Pedidos</div>
        <table class="table">
          <thead><tr><th>ID</th><th>Data</th><th>Itens</th><th>Total</th><th>Status</th><th>Ações</th></tr></thead>
          <tbody>
            ${orders.map(o=>`
              <tr data-oid="${o.id}">
                <td><span class="kbd">${o.id}</span></td>
                <td>${new Date(o.createdAt).toLocaleString()}</td>
                <td>${o.items.map(i=>`${i.qty}× ${i.name}`).join(", ")}</td>
                <td>R$ ${o.total.toFixed(2)}</td>
                <td>${o.status}</td>
                <td class="row">
                  <button class="btn-ghost" data-paid="${o.id}">Marcar pago</button>
                  <button class="btn-ghost" data-pending="${o.id}">Pendente</button>
                  <button class="btn-ghost" data-ticket="${o.id}">Abrir Ticket</button>
                </td>
              </tr>
            `).join("")}
          </tbody>
        </table>
      </div>
    `;
  }
  ticketsTab(s){
    const orders = listOrders(this.storeId);
    return `
      <div class="card">
        <div class="h2">Tickets por pedido</div>
        <div class="grid cols-2">
          ${orders.filter(o=>o.status==="paid").map(o=>{
            const t = ensureTicket(this.storeId, o.id);
            return `
              <div class="card" data-tid="${t.id}">
                <div class="row spread"><div>Pedido <span class="kbd">${o.id}</span></div><a class="badge" href="#/tickets/${this.storeId}">Ver como cliente</a></div>
                <div class="sep"></div>
                <div style="max-height:180px; overflow:auto; border:1px solid var(--line); border-radius:8px; padding:8px;">
                  ${t.messages.map(m=>`<div class="row" style="justify-content:${m.from==='admin'?'flex-end':'flex-start'}"><div class="badge">${m.from}</div><div>${m.text}</div></div>`).join("")}
                </div>
                <div class="row" style="margin-top:8px;">
                  <input placeholder="Mensagem..." data-msg="${t.id}">
                  <button class="btn-ghost" data-send="${t.id}">Enviar</button>
                </div>
              </div>
            `;
          }).join("")}
        </div>
        <div class="note" style="margin-top:8px;">Apenas pedidos pagos possuem tickets.</div>
      </div>
    `;
  }
  bindEvents(){
    const sId = this.storeId;
    this.el.querySelectorAll("#addProd").forEach(btn=>btn.addEventListener("click", ()=>{
      const name = this.el.querySelector("#pName").value.trim();
      const price = parseFloat(this.el.querySelector("#pPrice").value||"0");
      const categoryId = this.el.querySelector("#pCat").value||null;
      const stock = parseInt(this.el.querySelector("#pStock").value||"0");
      const image = this.el.querySelector("#pImg").value.trim();
      const description = this.el.querySelector("#pDesc").value.trim();
      if (!name || !price) return alert("Preencha nome e preço.");
      addProduct(sId, { name, price, categoryId, stock, image, description });
      location.reload();
    }));
    this.el.querySelectorAll("[data-del]").forEach(b=>b.addEventListener("click", ()=>{ removeProduct(sId, b.dataset.del); location.reload(); }));
    this.el.querySelectorAll("[data-edit]").forEach(b=>b.addEventListener("click", ()=>{
      const row = b.closest("tr"); const id = b.dataset.edit;
      const n = prompt("Novo nome:", row.children[0].textContent.trim()); if (!n) return;
      updateProduct(sId, id, { name:n }); location.reload();
    }));
    const addCat = this.el.querySelector("#addCat");
    if (addCat) addCat.addEventListener("click", ()=>{
      const name = this.el.querySelector("#cName").value.trim(); if(!name) return;
      addCategory(sId, name); location.reload();
    });
    this.el.querySelectorAll("[data-cdel]").forEach(b=>b.addEventListener("click", ()=>{ removeCategory(sId, b.dataset.cdel); location.reload(); }));
    const savePixBtn = this.el.querySelector("#savePix");
    if (savePixBtn) savePixBtn.addEventListener("click", ()=>{
      const key = this.el.querySelector("#pixKey").value.trim();
      const qrUrl = this.el.querySelector("#qrUrl").value.trim();
      setPix(sId, { key, qrUrl }); location.reload();
    });
    this.el.querySelectorAll("[data-paid]").forEach(b=>b.addEventListener("click", ()=>{ setOrderStatus(sId, b.dataset.paid, "paid"); ensureTicket(sId, b.dataset.paid); location.reload(); }));
    this.el.querySelectorAll("[data-pending]").forEach(b=>b.addEventListener("click", ()=>{ setOrderStatus(sId, b.dataset.pending, "pending"); location.reload(); }));
    this.el.querySelectorAll("[data-ticket]").forEach(b=>b.addEventListener("click", ()=>{ ensureTicket(sId, b.dataset.ticket); alert("Ticket criado/aberto."); }));
    this.el.querySelectorAll("[data-send]").forEach(btn=>btn.addEventListener("click", ()=>{
      const id = btn.dataset.send;
      const input = this.el.querySelector(`[data-msg="${id}"]`);
      const text = input.value.trim(); if (!text) return;
      import("store").then(({ postMessage })=>{ postMessage(sId, id, { from:"admin", text }); location.reload(); });
    }));
  }
}