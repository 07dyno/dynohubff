import { getStore, listOrders } from "store";

export class OrdersView {
  constructor(storeId){ this.storeId = storeId; }
  async render(){
    const s = getStore(this.storeId);
    const orders = listOrders(this.storeId);
    const el = document.createElement("div");
    el.innerHTML = `
      <header class="header">
        <div class="brand">${s.name}</div>
        <div class="nav">
          <a class="badge" href="#/store/${s.id}">Loja</a>
          <a class="badge" href="#/tickets/${s.id}">Tickets</a>
        </div>
      </header>
      <div class="container">
        <div class="card">
          <div class="h2">Meus pedidos</div>
          ${!orders.length ? `<div class="muted">Você ainda não fez pedidos.</div>` : `
          <table class="table">
            <thead><tr><th>ID</th><th>Data</th><th>Itens</th><th>Total</th><th>Status</th><th>Ticket</th></tr></thead>
            <tbody>
              ${orders.map(o=>`
                <tr>
                  <td><span class="kbd">${o.id}</span></td>
                  <td>${new Date(o.createdAt).toLocaleString()}</td>
                  <td>${o.items.map(i=>`${i.qty}× ${i.name}`).join(", ")}</td>
                  <td>R$ ${o.total.toFixed(2)}</td>
                  <td>${o.status}</td>
                  <td>
                    ${o.status==="paid" ? `<a class="badge" href="#/tickets/${s.id}" title="Abrir ticket">Abrir</a>` : `<span class="muted">Disponível após pagamento</span>`}
                  </td>
                </tr>
              `).join("")}
            </tbody>
          </table>`}
        </div>
      </div>
    `;
    return el;
  }
}

