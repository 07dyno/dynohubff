import { getStore, listOrders, ensureTicket, ticketByOrder, postMessage } from "store";

export class TicketsView {
  constructor(storeId){ this.storeId = storeId; }
  async render(){
    const s = getStore(this.storeId);
    const orders = listOrders(this.storeId).filter(o=>o.status==="paid");
    const el = document.createElement("div");
    el.innerHTML = `
      <header class="header">
        <div class="brand">${s.name}</div>
        <div class="nav">
          <a class="badge" href="#/orders/${s.id}">Pedidos</a>
          <a class="badge" href="#/store/${s.id}">Loja</a>
        </div>
      </header>
      <div class="container">
        <div class="card">
          <div class="h2">Tickets</div>
          ${!orders.length ? `<div class="muted">Nenhum pedido pago. Após a confirmação de pagamento, você poderá abrir um ticket.</div>` : `
            <div class="grid cols-2">
              ${orders.map(o=>{
                const t = ensureTicket(this.storeId, o.id);
                return `
                  <div class="card" data-tid="${t.id}">
                    <div class="row spread"><div>Pedido <span class="kbd">${o.id}</span></div><div class="badge">Status: ${o.status}</div></div>
                    <div style="max-height:220px; overflow:auto; border:1px solid var(--line); border-radius:8px; padding:8px; margin-top:8px;">
                      ${t.messages.map(m=>`
                        <div class="row" style="justify-content:${m.from==='me'?'flex-end':'flex-start'}; margin:4px 0;">
                          <div class="badge">${m.from}</div>
                          <div>${m.text}</div>
                        </div>`).join("")}
                    </div>
                    <div class="row" style="margin-top:8px;">
                      <input placeholder="Escreva sua mensagem..." data-msg="${t.id}">
                      <button class="btn-ghost" data-send="${t.id}">Enviar</button>
                    </div>
                  </div>
                `;
              }).join("")}
            </div>
          `}
        </div>
      </div>
    `;
    el.addEventListener("click",(e)=>{
      const btn = e.target.closest("[data-send]");
      if (!btn) return;
      const id = btn.dataset.send;
      const input = el.querySelector(`[data-msg="${id}"]`);
      const text = input.value.trim(); if(!text) return;
      postMessage(this.storeId, id, { from:"me", text });
      input.value=""; location.reload();
    });
    return el;
  }
}

