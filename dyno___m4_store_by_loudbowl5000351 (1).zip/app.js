import { Router } from "router";
import { ensureSeed, getSettings } from "store";

const appEl = document.getElementById("app");
ensureSeed();

const router = new Router(appEl);
router.start();

const bg = document.createElement("div"); bg.id="bgSlideshow"; document.body.appendChild(bg);
const supportWrap = document.createElement("div"); supportWrap.id="supportBtn"; document.body.appendChild(supportWrap);
const musicCtrl = document.createElement("div"); musicCtrl.id="musicCtrl"; musicCtrl.innerHTML = `<button id="musicToggle">▶︎</button>`; document.body.appendChild(musicCtrl);

const DEFAULT_BG = [
  "https://images.unsplash.com/photo-1548498900-3dfbdfff16d1?q=80&w=1600&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1549880338-65ddcdfd017b?q=80&w=1600&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1508057198894-247b23fe5ade?q=80&w=1600&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1519681393784-d120267933ba?q=80&w=1600&auto=format&fit=crop"
];
let bgList = DEFAULT_BG, idx=0;
function activeBgs(){
  const s = getSettings(); const hash = location.hash.slice(1) || "/";
  const [, route, storeId] = hash.split("/");
  if (route==="store" && s.storeBackgrounds?.[storeId]?.length) return s.storeBackgrounds[storeId];
  return s.homeBackgrounds?.length ? s.homeBackgrounds : DEFAULT_BG;
}
function applyBg(){ const next = activeBgs(); bgList = next.length?next:DEFAULT_BG; }
const swap=()=>{ applyBg(); bg.style.backgroundImage=`url('${bgList[idx%bgList.length]}')`; idx++; };
swap(); const bgTimer = setInterval(swap, 8000);

let audio; function applySettings(){ const s=getSettings(); supportWrap.innerHTML = s.supportLink ? `<a href="${s.supportLink}" target="_blank" rel="noopener">Suporte</a>` : ""; if (!audio){ audio = new Audio(s.musicUrl||"https://cdn.pixabay.com/download/audio/2022/08/24/audio_2e1ff68f47.mp3?filename=relaxing-ambient-115592.mp3"); audio.loop=true; } else if (s.musicUrl) { audio.src=s.musicUrl; } applyBg(); }
applySettings(); window.addEventListener("storage", e=>{ if(e.key==="dualshop.v1"){ applySettings(); }});
window.addEventListener("hashchange", applyBg);

document.addEventListener("click", ()=>{ if (audio && audio.paused) audio.play().catch(()=>{}); }, { once:true });
musicCtrl.addEventListener("click", (e)=>{ if(e.target.id==="musicToggle"){ if(!audio) return; if(audio.paused){ audio.play(); e.target.textContent="⏸"; } else { audio.pause(); e.target.textContent="▶︎"; } }});